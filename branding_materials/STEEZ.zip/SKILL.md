---
name: steez-design
description: Use this skill to generate well-branded interfaces and assets for STEEZ (steez.digital) — a Hangzhou digital studio helping Chinese factories win overseas buyers. Covers marketing carousels (Xiaohongshu / Instagram) plus the brand's colors, type, fonts, logos, and UI components. Use for production work or throwaway prototypes/mocks.
user-invocable: true
---

# STEEZ Design System — skill

Read **`readme.md`** in this folder first — it is the full design guide (company
context, content voice, visual foundations, iconography, and a file manifest).
Then explore the other files as needed.

## Quick orientation
- **Tokens / CSS:** `styles.css` (root) imports everything in `tokens/`. Link this one
  file to inherit all brand colors, type, spacing, and effects as CSS custom properties.
- **Components:** React primitives in `components/core/` and `components/marketing/`
  (Button, Pill, Badge, Card, Logo, Highlight, StatBlock, IconTile, StepNumber,
  WaveDecor). Each has a `.prompt.md` with usage. They reference the CSS variables.
- **Slide templates:** `slides/01-cover.html … 08-cta.html` — the 8-slide marketing
  carousel (1080×1080), self-contained and directly editable. `slides/index.html` is a
  swipeable viewer. `slides/_base.css` holds the shared slide shell.
- **Logos:** `assets/logo-steez-forest.png` (light bg), `assets/logo-steez-cream.png`
  (dark bg). For crisp scaling use the text-based `Logo` component.

## How to work
- **Visual artifacts** (slides, mocks, throwaway prototypes): copy the assets you need
  out, and produce static HTML files for the user to view. Start from a `slides/*.html`
  template and edit copy/colors, or compose components against `styles.css`.
- **Production code:** copy assets and follow the rules in `readme.md` to design as an
  expert in this brand.

## Non-negotiables (see readme.md for detail)
- Minimal, premium, lots of negative space. One idea / one hero line / one accent per slide.
- Gold is an **accent only**, never a background fill. One gold highlight per line.
- Chinese primary, English as accent. No emoji. Numbers lead.
- Never fabricate client logos, testimonials, or metrics; never fake product screenshots.
- Logo small, bottom-right. Mix light (cream) and dark (forest) slides across a carousel.

If invoked with no other guidance, ask the user what they want to build, ask a few
focused questions, then act as an expert STEEZ designer outputting HTML artifacts or
production code as needed.
