# STEEZ Design System

> Marketing-content design system for **STEEZ** (steez.digital) — a Hangzhou-based
> digital studio that helps Chinese manufacturers and exporters win overseas buyers.
> This system powers our **Xiaohongshu (小红书) and Instagram carousels** aimed at
> Chinese factory owners and export managers.

---

## 1. Company & product context

STEEZ replaces printed expo materials — business cards, catalogues, booth signage —
with **a single QR code** linking to a custom, multilingual, always-live digital
presence. We also run overseas-facing social-media and ad management for export
factories. Our edge: **foreign founders who know exactly what international buyers
expect to see.**

The audience for this design system's output is **Chinese factory owners & export
managers** who struggle to reach overseas buyers, waste expo spend, and hit
English/content barriers. STEEZ is positioned as the *foreign team that fixes their
overseas image*.

**Product lines referenced in marketing:** digital business cards, company profiles,
product catalogues, booth display, overseas social-media management. Only real demos
may be shown (`inwin-demo`, `toiletry-demo`) — never fabricated product screenshots.

### Sources used to build this system
- **Website:** https://steez.digital (hero, stat row, wave + halftone visual language)
- **GitHub repo (provided, not yet connected):** `STEEZ-Technologies/steez` —
  the live site source. Connect GitHub and re-run to pull exact wave geometry,
  component code, and any additional brand tokens. Explore it to build higher-fidelity
  designs from the real source rather than these reconstructions.
- **Uploaded reference carousels:** `uploads/1.png … 5.png` (existing STEEZ posts:
  before/after, pain points, data insight, 30-day process, free-audit CTA) — the
  slide templates here recreate this exact narrative and visual language.
- **Logo:** `uploads/Weixin Image_2026-06-15_164641_839.png` → cropped & recolored
  into `assets/logo-steez-forest.png` and `assets/logo-steez-cream.png`.

> ⚠️ **Substitution flag:** Brand font is **Helvetica Neue** (system). The Chinese hero
> face is **PingFang SC / Source Han Sans Heavy** (system on macOS/iOS; falls back to
> Microsoft YaHei / Noto Sans SC elsewhere). No webfont file was provided for these —
> if you have licensed Source Han Sans Heavy, upload it and we'll add the `@font-face`.
> Latin display/body/mono use **Cormorant Garamond, Syne, DM Sans, DM Mono** from
> Google Fonts.

---

## 2. Content fundamentals (voice & copy)

**Vibe:** Confident, direct, numbers-led, **no filler**. Premium studio, not busy
infographic. One idea per slide.

- **Language:** Chinese primary; English as *accent only* (a kicker label, a product
  term, a stat caption). Never a wall of English on a Chinese slide.
- **Person:** First person as **马修 (Matthew)**, the foreign founder — warm, direct —
  on Xiaohongshu. Use **您** (formal you) in business-direct copy.
- **Speak to real pain:** "展会花了20万，回来只有一叠没用的名片" / "社媒发了半年，询盘还是零" /
  "产品拍了几百张图，老外就是不感兴趣". Name the problem the buyer feels, then position
  STEEZ as the fix.
- **Numbers lead:** "带来 **3** 个海外询盘", "**90%** 的工厂主页连一条英文内容都没有",
  "**30 天** 从零到第一个海外询盘". One highlighted number per line.
- **Casing:** English kickers/labels are **UPPERCASE, wide-tracked** (DM Mono).
  Chinese headings are heavy/black, normal casing.
- **Emoji:** **Not used.** Brand uses gold dots, ticks (✓), and a send glyph (✈) as
  restrained iconography instead.
- **CTA pattern:** A concrete free offer + a one-word DM trigger — e.g.
  "私信发送「**诊断**」立即开始".

**Don'ts:** never fabricate client logos, testimonials, or fake metrics; never render
fake STEEZ product screenshots; don't overcrowd — when unsure, remove an element.

---

## 3. Visual foundations

**Design principle:** Minimal, stylish, premium. Lots of negative space. One hero line,
one accent. Restraint over decoration.

### Color
- **Forest Green `#04342C`** — primary: headings on light, OR full-bleed hero background.
- **Dark Forest `#0d1f18`** — deepest dark background.
- **Brushed Gold `#E0A93A`** (deep `#C8962A`) — **accent only**: CTAs, one highlighted
  word/number, pills, underlines. **Never a background fill.**
- **Cream Warm `#FEFCF7`** / **Cream `#FAF9F5`** / **Light Green `#EFF5F2`** — light
  backgrounds (cream is preferred & often best).
- **Red `#E24B4A`** — pain-point accents ONLY.
- **Gray `#6B7280`** — secondary text / captions.

**Background rhythm:** Mix light and dark across a carousel — cream slides (forest text)
for most, a few forest slides (cream text) for punctuation. Don't make every slide green.
Pain slides = cream/light-green with red accents. Solution/CTA = cream or forest with
gold accents.

### Type
- **Chinese hero:** PingFang SC / Source Han Sans **Heavy (900)** — big, bold, dominant,
  given room to breathe. 66–96px on a 1080 canvas.
- **Latin display:** Cormorant Garamond (serif mood) or Syne (modern mood).
- **Body:** DM Sans. **Labels / data / chips:** DM Mono, UPPERCASE, 0.16–0.2em tracking.
- **Wordmark / clean Latin:** Helvetica Neue (heavy).
- **Highlight technique:** set ONE key word/number in gold, the rest forest-green; an
  optional gold underline bar. One highlight per line, max.

### Spacing & layout
- 8px base grid. Slide safe-area padding ≈ **88px** on a 1080 canvas — whitespace is part
  of the design, never edge-to-edge.
- **Logo** sits small (~38px, ≈8% width) bottom-right; never dominant.
- Formats: Xiaohongshu carousel **1080×1080** (or 1080×1440 for reach), 8 slides;
  Instagram **1080×1080 / 1080×1350**, 5 slides.

### Signature textures & shapes (use sparingly)
- **Organic corner waves** — soft forest + gold ribbons bleeding off ONE or TWO corners
  (the website look). They frame content; they don't crowd it. See `WaveDecor`.
- **Halftone gold dots** — `#E0A93A`, ~14–15px spacing, ~2.6px radius, radial-gradient
  fade, **14–18% opacity**, anchored in one corner. A whisper, not a wall.
- **Thin gold accent bars** (2–3px) and **gold underlines** under one keyword.

### Cards, radius, shadow
- Cards: white, **8–10px radius**, soft shadow (`--shadow-card`), generous padding, with
  an optional colored **left rail** (gold = solution, red = pain).
- Pills/chips: **100px radius**. Icon tiles: rounded **18px** white squares.
- Shadows are **soft and low-opacity forest-tinted** — never harsh black.

### Motion & states
- Calm and premium: short fades / slides, easing `cubic-bezier(0.22,0.61,0.36,1)`,
  ~240ms. **No bounce, no infinite loops** on slide content.
- Hover: subtle lift + slightly deeper shadow (web). Press: gold deepens to `#C8962A`.
- Imagery vibe: warm, premium; product photography on dark slate (see reference).
  Forest/gold tint over photos via transparent color blocks for covers/dividers.

---

## 4. Iconography

- **Style:** simple **line icons**, ~2px stroke, rounded caps — rendered in **forest
  green**, or **red** on pain slides, or **gold** for solution accents. Filled glyphs
  only for the small status marks (✓ tick, ✈ send) inside discs/buttons.
- The reference carousels use this line-icon style (magnifier, phone-with-chart,
  document) inside white rounded **icon tiles** — recreated via the `IconTile`
  component with inline SVG icons.
- **Recommended set:** [Lucide](https://lucide.dev) (matches the 2px rounded-stroke
  look). Link from CDN or paste the SVG path into an `IconTile`. *Flagged substitution:*
  the original posts' icons are hand-placed; Lucide is the closest open equivalent and
  what these templates use.
- **Emoji:** not used. **Unicode marks** used sparingly as glyphs: ✓ (done), ✈ (DM/send),
  → (swipe), · (separator).
- **Logos:** STEEZ wordmark only for marketing (never the `ST=Z` bar motif). PNG marks in
  `assets/`; or the text-based `Logo` component for crisp scaling.

---

## 5. Index / manifest

**Foundations**
- `styles.css` — root entry (import lines only)
- `tokens/colors.css` · `typography.css` · `spacing.css` · `effects.css` · `fonts.css`
- `cards/` — foundation specimen cards (Colors, Type, Spacing, Brand)

**Assets**
- `assets/logo-steez-forest.png` — dark wordmark for light backgrounds
- `assets/logo-steez-cream.png` — light wordmark for dark backgrounds

**Components** (`window.DesignSystem_ff83d0.*`)
- Core (`components/core/`): `Button`, `Pill`, `Badge`, `Card`
- Marketing (`components/marketing/`): `Logo`, `Highlight`, `StatBlock`, `IconTile`,
  `StepNumber`, `WaveDecor`

**Slide templates** (`slides/`) — the 8-slide Xiaohongshu carousel
1. `01-cover.html` — forest hero hook
2. `02-comparison.html` — 改造前 / 改造后 (conceptual before/after)
3. `03-pain.html` — pain points, icon row, red accents
4. `04-data.html` — big gold stat insight
5. `05-solution.html` — one QR replaces everything (forest)
6. `06-process.html` — 30-day plan, numbered steps
7. `07-results.html` — stat grid (forest)
8. `08-cta.html` — free-audit offer, gold CTA
- `index.html` — swipeable viewer of all 8 slides

**Templates** (`templates/`) — copy-able editable carousel slides (Design Components)
- `carousel-slide/CarouselSlide.dc.html` — forest hero cover slide
- `carousel-cta/CarouselCta.dc.html` — cream closing CTA slide (free-offer + DM trigger)
- `carousel-data/CarouselData.dc.html` — cream insight slide (one knockout gold number)

**Skill**
- `SKILL.md` — Agent-Skills-compatible entry point

---

*To extend this system with higher fidelity, connect the `STEEZ-Technologies/steez`
GitHub repo and re-run — the live site source has the exact wave paths and any tokens
not visible from screenshots.*
