/* @ds-bundle: {"format":3,"namespace":"DesignSystem_ff83d0","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Pill","sourcePath":"components/core/Pill.jsx"},{"name":"Highlight","sourcePath":"components/marketing/Highlight.jsx"},{"name":"IconTile","sourcePath":"components/marketing/IconTile.jsx"},{"name":"Logo","sourcePath":"components/marketing/Logo.jsx"},{"name":"StatBlock","sourcePath":"components/marketing/StatBlock.jsx"},{"name":"StepNumber","sourcePath":"components/marketing/StepNumber.jsx"},{"name":"WaveDecor","sourcePath":"components/marketing/WaveDecor.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"5a832f6eab70","components/core/Button.jsx":"2e7733724242","components/core/Card.jsx":"def7bbf0726e","components/core/Pill.jsx":"6f480ccbe25f","components/marketing/Highlight.jsx":"b33d94dbb1dc","components/marketing/IconTile.jsx":"2aafdb3b927c","components/marketing/Logo.jsx":"142ec71744bc","components/marketing/StatBlock.jsx":"33415a48d74f","components/marketing/StepNumber.jsx":"ae11f8812af0","components/marketing/WaveDecor.jsx":"a8ea590cc563"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.DesignSystem_ff83d0 = window.DesignSystem_ff83d0 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Badge — small DM Mono kicker label, uppercase, wide tracking.
 * Sits above a heading as an eyebrow. Optional leading gold tick bar.
 */
function Badge({
  children,
  onDark = false,
  bar = true,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 12,
      fontFamily: "var(--font-mono)",
      fontWeight: 500,
      fontSize: 18,
      letterSpacing: "var(--ls-label)",
      textTransform: "uppercase",
      color: onDark ? "var(--text-on-dark-muted)" : "var(--text-muted)",
      ...style
    }
  }, rest), bar && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 32,
      height: 3,
      background: "var(--gold)",
      borderRadius: 2,
      flex: "none"
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * STEEZ Button — gold-filled CTA (primary), forest outline (secondary),
 * or quiet text (ghost). Calm press/hover, never bouncy.
 */
function Button({
  children,
  variant = "primary",
  size = "md",
  onDark = false,
  full = false,
  style = {},
  ...rest
}) {
  const pad = {
    sm: "12px 22px",
    md: "18px 34px",
    lg: "24px 46px"
  }[size] || "18px 34px";
  const fs = {
    sm: 16,
    md: 20,
    lg: 24
  }[size] || 20;
  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    fontFamily: "var(--font-sans)",
    fontWeight: 700,
    fontSize: fs,
    letterSpacing: "0.02em",
    padding: pad,
    borderRadius: "var(--r-pill)",
    border: "2px solid transparent",
    cursor: "pointer",
    width: full ? "100%" : "auto",
    transition: "transform var(--dur) var(--ease-out), box-shadow var(--dur) var(--ease-out), background var(--dur) var(--ease-out)",
    textDecoration: "none",
    whiteSpace: "nowrap"
  };
  const variants = {
    primary: {
      background: "var(--gold)",
      color: "var(--forest)",
      boxShadow: "var(--shadow-cta)"
    },
    secondary: {
      background: "transparent",
      color: onDark ? "var(--cream)" : "var(--forest)",
      borderColor: onDark ? "var(--cream)" : "var(--forest)"
    },
    ghost: {
      background: "transparent",
      color: onDark ? "var(--cream)" : "var(--forest)",
      padding: pad
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    style: {
      ...base,
      ...variants[variant],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Card — white rounded rectangle, soft shadow, generous padding.
 * Optional colored left rail: gold = solution, red = pain.
 */
function Card({
  children,
  rail = "none",
  // "none" | "solution" | "pain"
  onDark = false,
  style = {},
  ...rest
}) {
  const railColor = rail === "solution" ? "var(--gold)" : rail === "pain" ? "var(--red)" : null;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: onDark ? "var(--surface-card-dark)" : "var(--white)",
      borderRadius: "var(--r-card)",
      boxShadow: onDark ? "none" : "var(--shadow-card)",
      border: onDark ? "1px solid var(--line-dark)" : "1px solid rgba(4,52,44,0.04)",
      borderLeft: railColor ? `4px solid ${railColor}` : undefined,
      padding: "32px 36px",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Pill.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Pill / chip — rounded tag used for feature lists and categories.
 * On light: subtle cream/green fill. On dark: translucent.
 * Use `accent` for the one gold-highlighted chip.
 */
function Pill({
  children,
  accent = false,
  onDark = false,
  style = {},
  ...rest
}) {
  const base = {
    display: "inline-flex",
    alignItems: "center",
    gap: 8,
    fontFamily: "var(--font-body)",
    fontWeight: 600,
    fontSize: 20,
    lineHeight: 1,
    padding: "13px 22px",
    borderRadius: "var(--r-pill)",
    border: "1px solid",
    whiteSpace: "nowrap"
  };
  let look;
  if (accent) {
    look = {
      background: "var(--gold)",
      color: "var(--forest)",
      borderColor: "var(--gold)"
    };
  } else if (onDark) {
    look = {
      background: "rgba(250,249,245,0.08)",
      color: "var(--cream)",
      borderColor: "rgba(250,249,245,0.22)"
    };
  } else {
    look = {
      background: "var(--white)",
      color: "var(--forest)",
      borderColor: "var(--line)"
    };
  }
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      ...base,
      ...look,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Pill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Pill.jsx", error: String((e && e.message) || e) }); }

// components/marketing/Highlight.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Highlight — wraps the ONE gold keyword/number in a hero line.
 * Optional gold underline. One highlight per line, max.
 */
function Highlight({
  children,
  underline = false,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      color: "var(--gold)",
      backgroundImage: underline ? "linear-gradient(var(--gold), var(--gold))" : "none",
      backgroundRepeat: "no-repeat",
      backgroundPosition: "0 0.9em",
      backgroundSize: "100% 0.14em",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Highlight });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/Highlight.jsx", error: String((e && e.message) || e) }); }

// components/marketing/IconTile.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconTile — rounded white tile holding a single icon, with a caption.
 * Mirrors the pain/feature icon rows in STEEZ carousels. Pass the icon
 * (an <svg> / <img>) as children; tint it forest or red via `tone`.
 */
function IconTile({
  children,
  label,
  sub,
  tone = "forest",
  // "forest" | "gold" | "pain"
  style = {},
  ...rest
}) {
  const tint = tone === "pain" ? "var(--red)" : tone === "gold" ? "var(--gold-deep)" : "var(--forest)";
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      textAlign: "center",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 132,
      height: 132,
      borderRadius: 18,
      background: "var(--white)",
      boxShadow: "var(--shadow-card)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: tint
    }
  }, children), label && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-cn), var(--font-body)",
      fontWeight: 700,
      fontSize: 26,
      color: "var(--forest)",
      marginTop: 26
    }
  }, label), sub && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-cn), var(--font-body)",
      fontWeight: 400,
      fontSize: 20,
      lineHeight: 1.45,
      color: "var(--text-muted)",
      marginTop: 10,
      maxWidth: 240
    }
  }, sub));
}
Object.assign(__ds_scope, { IconTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/IconTile.jsx", error: String((e && e.message) || e) }); }

// components/marketing/Logo.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * STEEZ wordmark — heavy, all-caps Helvetica Neue with a gold ".digital"
 * superscript. Rendered as text so it stays crisp at any size.
 * Dark (forest) on light backgrounds; cream on dark. Sits small, usually
 * bottom-right of a slide (~8% width). Never dominant.
 */
function Logo({
  variant = "forest",
  size = 40,
  suffix = true,
  style = {},
  ...rest
}) {
  const wordColor = variant === "cream" ? "var(--cream)" : "var(--forest)";
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "flex-start",
      fontFamily: "var(--font-sans)",
      fontWeight: 800,
      fontSize: size,
      lineHeight: 1,
      letterSpacing: "-0.01em",
      color: wordColor,
      userSelect: "none",
      ...style
    }
  }, rest), "STEEZ", suffix && /*#__PURE__*/React.createElement("sup", {
    style: {
      fontSize: size * 0.34,
      fontWeight: 600,
      color: "var(--gold)",
      letterSpacing: 0,
      marginLeft: size * 0.02,
      position: "relative",
      top: "0.1em"
    }
  }, ".digital"));
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/Logo.jsx", error: String((e && e.message) || e) }); }

// components/marketing/StatBlock.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * StatBlock — big number + caption, as on the website stat row.
 * The number can carry one gold accent suffix (e.g. "+").
 */
function StatBlock({
  value,
  suffix,
  label,
  onDark = false,
  align = "left",
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      textAlign: align,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontWeight: 800,
      fontSize: 84,
      lineHeight: 1,
      letterSpacing: "-0.02em",
      color: onDark ? "var(--cream)" : "var(--forest)"
    }
  }, value, suffix && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--gold)"
    }
  }, suffix)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontWeight: 500,
      fontSize: 17,
      letterSpacing: "var(--ls-label)",
      textTransform: "uppercase",
      marginTop: 14,
      color: onDark ? "var(--text-on-dark-muted)" : "var(--text-muted)"
    }
  }, label));
}
Object.assign(__ds_scope, { StatBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/StatBlock.jsx", error: String((e && e.message) || e) }); }

// components/marketing/StepNumber.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * StepNumber — forest disc with a gold ring and a cream numeral.
 * Used in "how it works" / process timelines (e.g. the 30-day plan).
 */
function StepNumber({
  n,
  size = 92,
  done = false,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      width: size,
      height: size,
      borderRadius: "50%",
      background: done ? "var(--forest)" : "var(--forest)",
      border: "3px solid var(--gold)",
      boxShadow: "0 4px 14px rgba(4,52,44,0.18)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flex: "none",
      fontFamily: "var(--font-sans)",
      fontWeight: 800,
      fontSize: size * 0.46,
      color: "var(--cream)",
      ...style
    }
  }, rest), done ? "✓" : n);
}
Object.assign(__ds_scope, { StepNumber });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/StepNumber.jsx", error: String((e && e.message) || e) }); }

// components/marketing/WaveDecor.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * WaveDecor — STEEZ's signature organic curved shapes that bleed off the
 * corners of a slide (the website look). Forest + gold ribbons. Subtle:
 * it FRAMES the content, never crowds it. Renders as a full-bleed absolute
 * SVG; place inside a position:relative slide as the FIRST child.
 *
 * variant "cream"  -> forest+gold waves for a light (cream) slide
 * variant "forest" -> lighter-forest + gold waves for a dark slide
 * corners: which corners get a blob — ["tr","bl"] by default
 */
function WaveDecor({
  variant = "cream",
  corners = ["tr", "bl"],
  gold = true,
  style = {},
  ...rest
}) {
  const forest = variant === "cream" ? "#04342C" : "#0a4438";
  const forestSoft = variant === "cream" ? "#0a4d40" : "#0f5a49";
  const has = c => corners.includes(c);
  return /*#__PURE__*/React.createElement("svg", _extends({
    viewBox: "0 0 1080 1080",
    preserveAspectRatio: "none",
    "aria-hidden": "true",
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%",
      pointerEvents: "none",
      zIndex: 0,
      ...style
    }
  }, rest), has("tr") && /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("path", {
    d: "M1080,0 L1080,360 C940,330 860,250 820,150 C795,86 720,30 600,0 Z",
    fill: forest
  }), /*#__PURE__*/React.createElement("path", {
    d: "M1080,0 L1080,250 C980,235 905,180 860,96 C835,50 790,18 700,0 Z",
    fill: forestSoft,
    opacity: "0.9"
  }), gold && /*#__PURE__*/React.createElement("path", {
    d: "M1080,150 C960,150 880,108 832,28 C824,15 814,6 802,0",
    fill: "none",
    stroke: "#E0A93A",
    strokeWidth: "14",
    strokeLinecap: "round"
  })), has("bl") && /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("path", {
    d: "M0,1080 L0,720 C150,756 250,840 300,940 C330,1000 400,1050 520,1080 Z",
    fill: forest
  }), /*#__PURE__*/React.createElement("path", {
    d: "M0,1080 L0,840 C110,866 196,930 240,1004 C262,1042 300,1066 360,1080 Z",
    fill: forestSoft,
    opacity: "0.9"
  }), gold && /*#__PURE__*/React.createElement("path", {
    d: "M0,930 C120,930 206,978 256,1058 C262,1068 270,1075 280,1080",
    fill: "none",
    stroke: "#E0A93A",
    strokeWidth: "14",
    strokeLinecap: "round"
  })), has("tl") && /*#__PURE__*/React.createElement("path", {
    d: "M0,0 L0,300 C120,272 196,200 232,112 C256,54 320,16 420,0 Z",
    fill: forest
  }), has("br") && /*#__PURE__*/React.createElement("path", {
    d: "M1080,1080 L1080,780 C960,808 884,880 848,968 C824,1026 760,1064 660,1080 Z",
    fill: forest
  }));
}
Object.assign(__ds_scope, { WaveDecor });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/WaveDecor.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Pill = __ds_scope.Pill;

__ds_ns.Highlight = __ds_scope.Highlight;

__ds_ns.IconTile = __ds_scope.IconTile;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.StatBlock = __ds_scope.StatBlock;

__ds_ns.StepNumber = __ds_scope.StepNumber;

__ds_ns.WaveDecor = __ds_scope.WaveDecor;

})();
