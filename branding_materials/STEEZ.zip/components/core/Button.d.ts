import React from "react";

export type ButtonVariant = "primary" | "secondary" | "ghost";
export type ButtonSize = "sm" | "md" | "lg";

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Visual style. primary = gold fill (CTA), secondary = outline, ghost = text-only */
  variant?: ButtonVariant;
  size?: ButtonSize;
  /** Set true when the button sits on a forest/dark background */
  onDark?: boolean;
  /** Stretch to container width */
  full?: boolean;
  children?: React.ReactNode;
}

export function Button(props: ButtonProps): JSX.Element;
