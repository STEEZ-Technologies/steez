White rounded card with soft shadow; optional colored left rail.

```jsx
<Card rail="solution"><h3>重建海外获客基础</h3><p>英文主页改造 + 品牌视觉升级</p></Card>
<Card rail="pain">展会花了20万，回来只有一叠名片</Card>
```

`rail`: `"solution"` (gold) for fixes, `"pain"` (red) for problems, `"none"` default. Pass `onDark` for forest slides (lifted surface, no shadow). Generous padding is built in.
