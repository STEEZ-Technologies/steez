import React from "react";

export type CardRail = "none" | "solution" | "pain";

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Colored left rail: gold (solution) or red (pain) */
  rail?: CardRail;
  /** Lifted-forest surface for dark slides */
  onDark?: boolean;
  children?: React.ReactNode;
}

/** White rounded card with soft shadow + optional colored left rail. */
export function Card(props: CardProps): JSX.Element;
