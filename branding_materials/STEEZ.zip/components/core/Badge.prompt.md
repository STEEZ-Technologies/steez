DM Mono eyebrow label that sits above a hero heading (e.g. "STEEZ · 海外获客").

```jsx
<Badge>海外获客 / OVERSEAS LEADS</Badge>
<Badge onDark bar={false}>STEEZ.DIGITAL</Badge>
```

Uppercase, wide tracking, optional leading gold bar. Pass `onDark` on forest backgrounds.
