import React from "react";

/**
 * STEEZ Button — gold-filled CTA (primary), forest outline (secondary),
 * or quiet text (ghost). Calm press/hover, never bouncy.
 */
export function Button({
  children,
  variant = "primary",
  size = "md",
  onDark = false,
  full = false,
  style = {},
  ...rest
}) {
  const pad = { sm: "12px 22px", md: "18px 34px", lg: "24px 46px" }[size] || "18px 34px";
  const fs = { sm: 16, md: 20, lg: 24 }[size] || 20;

  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    fontFamily: "var(--font-sans)",
    fontWeight: 700,
    fontSize: fs,
    letterSpacing: "0.02em",
    padding: pad,
    borderRadius: "var(--r-pill)",
    border: "2px solid transparent",
    cursor: "pointer",
    width: full ? "100%" : "auto",
    transition: "transform var(--dur) var(--ease-out), box-shadow var(--dur) var(--ease-out), background var(--dur) var(--ease-out)",
    textDecoration: "none",
    whiteSpace: "nowrap",
  };

  const variants = {
    primary: {
      background: "var(--gold)",
      color: "var(--forest)",
      boxShadow: "var(--shadow-cta)",
    },
    secondary: {
      background: "transparent",
      color: onDark ? "var(--cream)" : "var(--forest)",
      borderColor: onDark ? "var(--cream)" : "var(--forest)",
    },
    ghost: {
      background: "transparent",
      color: onDark ? "var(--cream)" : "var(--forest)",
      padding: pad,
    },
  };

  return (
    <button style={{ ...base, ...variants[variant], ...style }} {...rest}>
      {children}
    </button>
  );
}
