Rounded tag/chip for feature lists (mirrors the "Digital cards · Company profiles · Booth display" row on the site).

```jsx
<Pill>数字名片</Pill>
<Pill accent>海外获客</Pill>
<Pill onDark>Booth display</Pill>
```

`accent` gives one chip the gold fill; `onDark` makes it translucent on forest. Keep rows to one accent chip max.
