Gold-filled CTA button (and outline / ghost variants) — use for the single action on a STEEZ CTA slide or web hero.

```jsx
<Button variant="primary" size="lg">立即诊断</Button>
<Button variant="secondary" onDark>了解更多</Button>
```

Variants: `primary` (gold fill, forest text — the CTA), `secondary` (outline), `ghost` (text only). Sizes `sm | md | lg`. Pass `onDark` on forest backgrounds so outline/ghost flip to cream. One primary button per slide — it's the single accent.
