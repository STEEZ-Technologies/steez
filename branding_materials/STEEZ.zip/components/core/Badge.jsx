import React from "react";

/**
 * Badge — small DM Mono kicker label, uppercase, wide tracking.
 * Sits above a heading as an eyebrow. Optional leading gold tick bar.
 */
export function Badge({ children, onDark = false, bar = true, style = {}, ...rest }) {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 12,
        fontFamily: "var(--font-mono)",
        fontWeight: 500,
        fontSize: 18,
        letterSpacing: "var(--ls-label)",
        textTransform: "uppercase",
        color: onDark ? "var(--text-on-dark-muted)" : "var(--text-muted)",
        ...style,
      }}
      {...rest}
    >
      {bar && (
        <span
          style={{
            width: 32,
            height: 3,
            background: "var(--gold)",
            borderRadius: 2,
            flex: "none",
          }}
        />
      )}
      {children}
    </span>
  );
}
