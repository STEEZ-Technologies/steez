import React from "react";

/**
 * Card — white rounded rectangle, soft shadow, generous padding.
 * Optional colored left rail: gold = solution, red = pain.
 */
export function Card({
  children,
  rail = "none", // "none" | "solution" | "pain"
  onDark = false,
  style = {},
  ...rest
}) {
  const railColor = rail === "solution" ? "var(--gold)" : rail === "pain" ? "var(--red)" : null;

  return (
    <div
      style={{
        background: onDark ? "var(--surface-card-dark)" : "var(--white)",
        borderRadius: "var(--r-card)",
        boxShadow: onDark ? "none" : "var(--shadow-card)",
        border: onDark ? "1px solid var(--line-dark)" : "1px solid rgba(4,52,44,0.04)",
        borderLeft: railColor ? `4px solid ${railColor}` : undefined,
        padding: "32px 36px",
        ...style,
      }}
      {...rest}
    >
      {children}
    </div>
  );
}
