import React from "react";

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Lighter color for forest/dark backgrounds */
  onDark?: boolean;
  /** Show the leading gold tick bar (default true) */
  bar?: boolean;
  children?: React.ReactNode;
}

/** DM Mono eyebrow / kicker label, uppercase + wide tracking. */
export function Badge(props: BadgeProps): JSX.Element;
