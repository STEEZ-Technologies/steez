import React from "react";

/**
 * Pill / chip — rounded tag used for feature lists and categories.
 * On light: subtle cream/green fill. On dark: translucent.
 * Use `accent` for the one gold-highlighted chip.
 */
export function Pill({ children, accent = false, onDark = false, style = {}, ...rest }) {
  const base = {
    display: "inline-flex",
    alignItems: "center",
    gap: 8,
    fontFamily: "var(--font-body)",
    fontWeight: 600,
    fontSize: 20,
    lineHeight: 1,
    padding: "13px 22px",
    borderRadius: "var(--r-pill)",
    border: "1px solid",
    whiteSpace: "nowrap",
  };

  let look;
  if (accent) {
    look = { background: "var(--gold)", color: "var(--forest)", borderColor: "var(--gold)" };
  } else if (onDark) {
    look = {
      background: "rgba(250,249,245,0.08)",
      color: "var(--cream)",
      borderColor: "rgba(250,249,245,0.22)",
    };
  } else {
    look = {
      background: "var(--white)",
      color: "var(--forest)",
      borderColor: "var(--line)",
    };
  }

  return (
    <span style={{ ...base, ...look, ...style }} {...rest}>
      {children}
    </span>
  );
}
