import React from "react";

export interface PillProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Gold fill — use for at most one highlighted chip in a row */
  accent?: boolean;
  /** Translucent treatment for forest/dark backgrounds */
  onDark?: boolean;
  children?: React.ReactNode;
}

/** Rounded tag/chip for feature lists and categories. */
export function Pill(props: PillProps): JSX.Element;
