Sets the single gold keyword/number inside a forest-green hero line.

```jsx
<h1>一条领英帖子，带来 <Highlight>3</Highlight> 个海外询盘</h1>
<h1>但 <Highlight underline>90%</Highlight> 的工厂主页…</h1>
```

One highlight per line, maximum. `underline` adds the gold bar beneath.
