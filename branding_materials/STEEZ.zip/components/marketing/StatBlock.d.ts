import React from "react";

export interface StatBlockProps extends React.HTMLAttributes<HTMLDivElement> {
  /** The headline number, e.g. "1,247" or "90" */
  value: React.ReactNode;
  /** Optional gold accent suffix, e.g. "+" or "%" */
  suffix?: React.ReactNode;
  /** DM Mono uppercase caption */
  label: React.ReactNode;
  onDark?: boolean;
  align?: "left" | "center";
}

/** Big number + mono caption (the website stat row). */
export function StatBlock(props: StatBlockProps): JSX.Element;
