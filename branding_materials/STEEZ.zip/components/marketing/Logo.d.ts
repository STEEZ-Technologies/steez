import React from "react";

export type LogoVariant = "forest" | "cream";

export interface LogoProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** forest = dark wordmark (light bg); cream = light wordmark (dark bg) */
  variant?: LogoVariant;
  /** Wordmark cap height in px */
  size?: number;
  /** Show the gold ".digital" superscript (default true) */
  suffix?: boolean;
}

export function Logo(props: LogoProps): JSX.Element;
