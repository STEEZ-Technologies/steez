import React from "react";

export interface HighlightProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Add a gold underline beneath the keyword */
  underline?: boolean;
  children?: React.ReactNode;
}

/** Gold keyword/number emphasis inside a hero line. One per line max. */
export function Highlight(props: HighlightProps): JSX.Element;
