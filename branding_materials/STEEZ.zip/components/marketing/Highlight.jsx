import React from "react";

/**
 * Highlight — wraps the ONE gold keyword/number in a hero line.
 * Optional gold underline. One highlight per line, max.
 */
export function Highlight({ children, underline = false, style = {}, ...rest }) {
  return (
    <span
      style={{
        color: "var(--gold)",
        backgroundImage: underline ? "linear-gradient(var(--gold), var(--gold))" : "none",
        backgroundRepeat: "no-repeat",
        backgroundPosition: "0 0.9em",
        backgroundSize: "100% 0.14em",
        ...style,
      }}
      {...rest}
    >
      {children}
    </span>
  );
}
