import React from "react";

/**
 * WaveDecor — STEEZ's signature organic curved shapes that bleed off the
 * corners of a slide (the website look). Forest + gold ribbons. Subtle:
 * it FRAMES the content, never crowds it. Renders as a full-bleed absolute
 * SVG; place inside a position:relative slide as the FIRST child.
 *
 * variant "cream"  -> forest+gold waves for a light (cream) slide
 * variant "forest" -> lighter-forest + gold waves for a dark slide
 * corners: which corners get a blob — ["tr","bl"] by default
 */
export function WaveDecor({
  variant = "cream",
  corners = ["tr", "bl"],
  gold = true,
  style = {},
  ...rest
}) {
  const forest = variant === "cream" ? "#04342C" : "#0a4438";
  const forestSoft = variant === "cream" ? "#0a4d40" : "#0f5a49";
  const has = (c) => corners.includes(c);

  return (
    <svg
      viewBox="0 0 1080 1080"
      preserveAspectRatio="none"
      aria-hidden="true"
      style={{
        position: "absolute",
        inset: 0,
        width: "100%",
        height: "100%",
        pointerEvents: "none",
        zIndex: 0,
        ...style,
      }}
      {...rest}
    >
      {has("tr") && (
        <g>
          <path
            d="M1080,0 L1080,360 C940,330 860,250 820,150 C795,86 720,30 600,0 Z"
            fill={forest}
          />
          <path
            d="M1080,0 L1080,250 C980,235 905,180 860,96 C835,50 790,18 700,0 Z"
            fill={forestSoft}
            opacity="0.9"
          />
          {gold && (
            <path
              d="M1080,150 C960,150 880,108 832,28 C824,15 814,6 802,0"
              fill="none"
              stroke="#E0A93A"
              strokeWidth="14"
              strokeLinecap="round"
            />
          )}
        </g>
      )}
      {has("bl") && (
        <g>
          <path
            d="M0,1080 L0,720 C150,756 250,840 300,940 C330,1000 400,1050 520,1080 Z"
            fill={forest}
          />
          <path
            d="M0,1080 L0,840 C110,866 196,930 240,1004 C262,1042 300,1066 360,1080 Z"
            fill={forestSoft}
            opacity="0.9"
          />
          {gold && (
            <path
              d="M0,930 C120,930 206,978 256,1058 C262,1068 270,1075 280,1080"
              fill="none"
              stroke="#E0A93A"
              strokeWidth="14"
              strokeLinecap="round"
            />
          )}
        </g>
      )}
      {has("tl") && (
        <path d="M0,0 L0,300 C120,272 196,200 232,112 C256,54 320,16 420,0 Z" fill={forest} />
      )}
      {has("br") && (
        <path
          d="M1080,1080 L1080,780 C960,808 884,880 848,968 C824,1026 760,1064 660,1080 Z"
          fill={forest}
        />
      )}
    </svg>
  );
}
