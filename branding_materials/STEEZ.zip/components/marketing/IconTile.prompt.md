Rounded white tile holding one icon plus a caption — the pain-point / feature icon rows in STEEZ carousels. Pass the icon (Lucide SVG / `<img>`) as children.

```jsx
<IconTile tone="pain" label="找不到精准客户" sub="展会花了20万，回来只有一叠名片">
  <svg width="56" height="56">…magnifier…</svg>
</IconTile>
```

`tone`: `forest` (default), `gold`, or `pain` (red) tints the icon. Three tiles per row reads cleanest.
