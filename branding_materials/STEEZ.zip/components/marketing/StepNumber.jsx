import React from "react";

/**
 * StepNumber — forest disc with a gold ring and a cream numeral.
 * Used in "how it works" / process timelines (e.g. the 30-day plan).
 */
export function StepNumber({ n, size = 92, done = false, style = {}, ...rest }) {
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: "50%",
        background: done ? "var(--forest)" : "var(--forest)",
        border: "3px solid var(--gold)",
        boxShadow: "0 4px 14px rgba(4,52,44,0.18)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flex: "none",
        fontFamily: "var(--font-sans)",
        fontWeight: 800,
        fontSize: size * 0.46,
        color: "var(--cream)",
        ...style,
      }}
      {...rest}
    >
      {done ? "✓" : n}
    </div>
  );
}
