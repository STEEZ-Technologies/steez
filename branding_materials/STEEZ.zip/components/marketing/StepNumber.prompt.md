Numbered forest disc with a gold ring — process/timeline steps (the "30 天" plan slide).

```jsx
<StepNumber n={1} />
<StepNumber done />   {/* final result step → checkmark */}
```

`size` sets the diameter; `done` swaps the numeral for a checkmark. Stack vertically with gold connector lines for a timeline.
