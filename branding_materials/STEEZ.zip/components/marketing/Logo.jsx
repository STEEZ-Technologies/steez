import React from "react";

/**
 * STEEZ wordmark — heavy, all-caps Helvetica Neue with a gold ".digital"
 * superscript. Rendered as text so it stays crisp at any size.
 * Dark (forest) on light backgrounds; cream on dark. Sits small, usually
 * bottom-right of a slide (~8% width). Never dominant.
 */
export function Logo({ variant = "forest", size = 40, suffix = true, style = {}, ...rest }) {
  const wordColor = variant === "cream" ? "var(--cream)" : "var(--forest)";
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "flex-start",
        fontFamily: "var(--font-sans)",
        fontWeight: 800,
        fontSize: size,
        lineHeight: 1,
        letterSpacing: "-0.01em",
        color: wordColor,
        userSelect: "none",
        ...style,
      }}
      {...rest}
    >
      STEEZ
      {suffix && (
        <sup
          style={{
            fontSize: size * 0.34,
            fontWeight: 600,
            color: "var(--gold)",
            letterSpacing: 0,
            marginLeft: size * 0.02,
            position: "relative",
            top: "0.1em",
          }}
        >
          .digital
        </sup>
      )}
    </span>
  );
}
