import React from "react";

export interface StepNumberProps extends React.HTMLAttributes<HTMLDivElement> {
  /** The step number to display */
  n?: React.ReactNode;
  /** Diameter in px (default 92) */
  size?: number;
  /** Render a checkmark instead of a number (final result step) */
  done?: boolean;
}

/** Forest disc + gold ring + cream numeral for process timelines. */
export function StepNumber(props: StepNumberProps): JSX.Element;
