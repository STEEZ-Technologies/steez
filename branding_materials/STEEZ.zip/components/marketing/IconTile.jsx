import React from "react";

/**
 * IconTile — rounded white tile holding a single icon, with a caption.
 * Mirrors the pain/feature icon rows in STEEZ carousels. Pass the icon
 * (an <svg> / <img>) as children; tint it forest or red via `tone`.
 */
export function IconTile({
  children,
  label,
  sub,
  tone = "forest", // "forest" | "gold" | "pain"
  style = {},
  ...rest
}) {
  const tint = tone === "pain" ? "var(--red)" : tone === "gold" ? "var(--gold-deep)" : "var(--forest)";
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", ...style }} {...rest}>
      <div
        style={{
          width: 132,
          height: 132,
          borderRadius: 18,
          background: "var(--white)",
          boxShadow: "var(--shadow-card)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: tint,
        }}
      >
        {children}
      </div>
      {label && (
        <div
          style={{
            fontFamily: "var(--font-cn), var(--font-body)",
            fontWeight: 700,
            fontSize: 26,
            color: "var(--forest)",
            marginTop: 26,
          }}
        >
          {label}
        </div>
      )}
      {sub && (
        <div
          style={{
            fontFamily: "var(--font-cn), var(--font-body)",
            fontWeight: 400,
            fontSize: 20,
            lineHeight: 1.45,
            color: "var(--text-muted)",
            marginTop: 10,
            maxWidth: 240,
          }}
        >
          {sub}
        </div>
      )}
    </div>
  );
}
