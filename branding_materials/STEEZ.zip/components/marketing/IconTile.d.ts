import React from "react";

export type IconTileTone = "forest" | "gold" | "pain";

export interface IconTileProps extends React.HTMLAttributes<HTMLDivElement> {
  /** The icon element (svg/img) */
  children?: React.ReactNode;
  /** Bold caption under the tile */
  label?: React.ReactNode;
  /** Smaller supporting line */
  sub?: React.ReactNode;
  /** Icon tint */
  tone?: IconTileTone;
}

/** Rounded white icon tile with caption — pain/feature icon rows. */
export function IconTile(props: IconTileProps): JSX.Element;
