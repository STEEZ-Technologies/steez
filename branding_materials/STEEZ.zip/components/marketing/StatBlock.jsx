import React from "react";

/**
 * StatBlock — big number + caption, as on the website stat row.
 * The number can carry one gold accent suffix (e.g. "+").
 */
export function StatBlock({
  value,
  suffix,
  label,
  onDark = false,
  align = "left",
  style = {},
  ...rest
}) {
  return (
    <div style={{ textAlign: align, ...style }} {...rest}>
      <div
        style={{
          fontFamily: "var(--font-sans)",
          fontWeight: 800,
          fontSize: 84,
          lineHeight: 1,
          letterSpacing: "-0.02em",
          color: onDark ? "var(--cream)" : "var(--forest)",
        }}
      >
        {value}
        {suffix && <span style={{ color: "var(--gold)" }}>{suffix}</span>}
      </div>
      <div
        style={{
          fontFamily: "var(--font-mono)",
          fontWeight: 500,
          fontSize: 17,
          letterSpacing: "var(--ls-label)",
          textTransform: "uppercase",
          marginTop: 14,
          color: onDark ? "var(--text-on-dark-muted)" : "var(--text-muted)",
        }}
      >
        {label}
      </div>
    </div>
  );
}
