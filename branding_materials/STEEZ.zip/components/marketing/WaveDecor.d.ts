import React from "react";

export type WaveVariant = "cream" | "forest";
export type WaveCorner = "tr" | "tl" | "br" | "bl";

export interface WaveDecorProps extends React.SVGAttributes<SVGElement> {
  /** cream = waves for a light slide; forest = waves for a dark slide */
  variant?: WaveVariant;
  /** Which corners get an organic blob (default ["tr","bl"]) */
  corners?: WaveCorner[];
  /** Include the thin gold ribbon accent (default true) */
  gold?: boolean;
}

/** Signature organic corner waves (the steez.digital look). Full-bleed absolute SVG. */
export function WaveDecor(props: WaveDecorProps): JSX.Element;
