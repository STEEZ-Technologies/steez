Big knockout number with a DM Mono caption — the results/proof stat (matches the site's "1,247+ · 38 · 90 · 3" row).

```jsx
<StatBlock value="1,247" suffix="+" label="Buyer scans activated" />
<StatBlock value="90" label="天出结果" align="center" onDark />
```

`suffix` renders in gold. `align` left/center; `onDark` for forest slides.
