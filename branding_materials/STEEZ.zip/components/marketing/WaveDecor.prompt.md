Signature organic corner waves — forest + gold ribbons bleeding off the corners, mirroring the steez.digital site. Frames content, never crowds it.

```jsx
<div style={{ position: "relative" }}>
  <WaveDecor variant="cream" corners={["tr", "bl"]} />
  {/* slide content with zIndex:1 above it */}
</div>
```

Put it as the FIRST child of a `position:relative` slide; give your real content `position:relative; zIndex:1`. `variant`: `cream` (light slide) or `forest` (dark slide). Limit to one or two corners — restraint.
