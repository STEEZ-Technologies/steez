The STEEZ wordmark — heavy Helvetica Neue caps with a gold ".digital" superscript. Goes small in a slide's bottom-right corner.

```jsx
<Logo variant="forest" size={40} />   {/* on cream */}
<Logo variant="cream" size={40} />    {/* on forest */}
```

`variant`: `forest` (dark, for light bg) or `cream` (light, for dark bg). Keep it small (~8% slide width) and out of the way — never the focal element. PNG marks also live in `assets/logo-steez-*.png` if you need the exact file.
